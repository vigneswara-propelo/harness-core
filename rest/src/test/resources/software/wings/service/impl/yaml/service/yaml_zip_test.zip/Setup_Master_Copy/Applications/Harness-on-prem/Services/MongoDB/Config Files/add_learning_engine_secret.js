use HARNESSDB;

db.getCollection('serviceSecrets').insert({
    "_id" : "djEzvOJtTFSvpglImf1fXg",
    "serviceSecret" : "LEARNING_ENGINE_SECRET",
    "serviceType" : "LEARNING_ENGINE",
    "createdAt" : NumberLong(1518718228292),
    "lastUpdatedAt" : NumberLong(1518718228292)
});